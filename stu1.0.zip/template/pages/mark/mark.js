// pages/mark/mark.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    markList: [],
    title: '',
    avgMark:0
  },
  //模糊查询成绩信息
  titleChanged(e) {
    let that = this;
    //console.log(e)
    wx.request({
      url: 'https://www.talkischeap0.cn/student/marks',
      data: {
        //用于测试
        'sId': '123',
        //'sId':wx.getStorageSync('student').sId,
        'title': e.detail.value.title
      },
      header: {},
      method: 'GET',
      dataType: 'json',
      responseType: 'text',
      success: function (res) {
        //console.log(res);
        that.setData({
          markList: res.data.markList
        })
      }
    })
  },
  //翻转成绩数组
  reverse() {
    let newMarkList = this.data.markList.reverse();
    this.setData({
      markList: newMarkList
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let that = this;
    wx.request({
      url: 'https://www.talkischeap0.cn/student/marks',
      data: {
        //用于测试
        'sId': '123',
        //'sId':wx.getStorageSync('student').sId,
        'title': that.data.title
      },
      header: {},
      method: 'GET',
      dataType: 'json',
      responseType: 'text',
      success: function (res) {
        //console.log(res);
        let total=0;
        for(let i in res.data.markList){
          total += res.data.markList[i].mark
        }
        that.setData({
          markList: res.data.markList,
          avgMark:total/res.data.markList.length        })
      }
    })

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    wx.reLaunch({
      url: 'mark',
      success: function (res) { },
      fail: function (res) { },
      complete: function (res) { },
    })
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})