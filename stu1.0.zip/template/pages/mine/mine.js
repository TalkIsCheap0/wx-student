// pages/mine/mine.js
const app=getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    loadingGif: false,
    student: {},
    hiddenUpdatePwd: true,
    curPwd: '',
    newPwd1: '',
    newPwd2: '',
  },
  // 弹框修改密码
  showUpdatePwdModal() {
    this.setData({
      hiddenUpdatePwd: false
    })
  },
  cancel() {
    this.setData({
      hiddenUpdatePwd: true
    })
  },
  updatePwd(e) {
    // console.log(e)
    let that = this;
    if (this.data.newPwd1 != this.data.newPwd2) {
      wx.showToast({
        title: '新密码不一致',
        icon: 'none'
      })
    }
    else if (this.data.curPwd != this.data.student.pwd) {
      wx.showToast({
        title: '原密码错误',
        icon: 'none'
      })
    }
    else {
      wx.request({
        url: 'https://www.talkischeap0.cn/student/updatePwd',
        data: { sId: '123', pwd: that.data.curPwd, newPwd: that.data.newPwd1 },
        header: {},
        method: 'GET',
        dataType: 'json',
        responseType: 'text',
        success: function (res) {
          // console.log(res)
          if (res.data.code == 200) {
            wx.showToast({
              title: '成功！重新登录',
              duration: 1000,
              success: function (res) {
                setTimeout(function () {
                  wx.reLaunch({
                    url: '../login/login',
                    success: function (res) { },
                    fail: function (res) { },
                    complete: function (res) { },
                  })
                }, 1000)

              },
            })
          }
          else {
            wx.showToast({
              title: '修改失败',
              complete() {
                that.setData({
                  hiddenUpdatePwd: true
                })
              }
            })
          }
        },
        fail: function (res) { },
        complete: function (res) { },
      })
    }
  },
  //pwd handler
  curPwd(e) {
    this.setData({
      curPwd: e.detail.value
    })
  },
  newPwd1(e) {
    this.setData({
      newPwd1: e.detail.value
    })
  },
  newPwd2(e) {
    this.setData({
      newPwd2: e.detail.value
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      //调用缓存
      student: wx.getStorageSync("student")
    })
    let that = this;
    // 获取用户信息
    wx.getSetting({
      success: res => {
        if (res.authSetting['scope.userInfo']) {
          // 已经授权，可以直接调用 getUserInfo 获取头像昵称，不会弹框
          wx.getUserInfo({
            success: res => {
              that.setData({
                avatarUrl: res.userInfo.avatarUrl,
                nickName: res.userInfo.nickName,
              })
              // 可以将 res 发送给后台解码出 unionId
              // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
              // 所以此处加入 callback 以防止这种情况
              if (this.userInfoReadyCallback) {
                this.userInfoReadyCallback(res)
              }
            }
          })
        }
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
    setTimeout(() => {
      //wx.hideLoading()
      this.setData({
        loadingGif: true
      })
    }, 2000)
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})