// pages/teacher/course/classcourse/classcourse.js
var app = getApp();
Page({

  data: {
    weekArray: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20],
    index: 0,
    student:wx.getStorageSync('student'),
    currentCourseList: [],
  },

  onLoad(options) {
    let that = this;
    wx.request({
      url: 'https://www.talkischeap0.cn/student/course',
      data: {
        cName: that.data.student.cName,
        week:that.data.index
      },
      success(res) {
        // console.log(res)
        let arr1 = [];
        for (let j = 0; j < 5; j++) {
          let arr0 = [];
          for (let i = j; i < 35; i += 5) {
            arr0.push(res.data.courseList[i]);
          }
          arr1.push(arr0);
        };
        that.setData({
          currentCourseList: arr1
        })

      }
    });
    
  },
  bindPickerChange(e) {
    // console.log(e);
    this.setData({
      index: e.detail.value
    });
    let that = this;
    wx.request({
      url: 'https://www.talkischeap0.cn/student/course',
      data: {
        cName: that.data.student.cName,
        week: that.data.index
      },
      success(res) {
        console.log(res)
        let arr1 = [];
        for (let j = 0; j < 5; j++) {
          let arr0 = [];
          for (let i = j; i < 35; i += 5) {
            arr0.push(res.data.courseList[i]);
          }
          arr1.push(arr0);
        };
        that.setData({
          currentCourseList: arr1
        })

      }
    });
  }
})
