Page({
  data: {
    cardCur: 0,
    swiperList: [],
    advice: {},
    src: []
  },
  delAdvice(e) {
    wx.request({
      url: 'https://www.talkischeap0.cn/student/delAdvice?id=' + this.data.advice.id,
      success(res) {
        wx.reLaunch({
          url: '../advice/advice'
        })
      }
    })
  },
  updateFlag(e) {
    let newflag = this.data.advice.flag == '0' ? '1' : '0';
    wx.request({
      url: 'https://www.talkischeap0.cn/student/updateFlag?id=' + this.data.advice.id + '&flag=' + newflag,
      success(res) {
        wx.reLaunch({
          url: '../advice/advice'
        })
      }
    })
  },
  onLoad(options) {
    // console.log(options.advice)
    this.setData({
      advice: JSON.parse(options.advice),
      src: JSON.parse(options.advice).img
    })
    let arr=[],brr=[];
    for(let i in this.data.src){
      let a={}
      a.id=i,
        a.url = 'https://www.talkischeap0.cn/'+this.data.src[i],
      a.tpye='';
      arr.push(a);
      brr.push(a.url)
    }
    this.setData({
      swiperList:arr,
      src:brr
    })
    this.towerSwiper('swiperList');
    // 初始化towerSwiper 传已有的数组名即可
  },
  //预览图片
  preImg(e){
    let current=e.currentTarget.dataset.src;
   wx.previewImage({
     current: current,
     urls: this.data.src
    //  success: function(res) {},
    //  fail: function(res) {},
    //  complete: function(res) {},
   })
  },
  DotStyle(e) {
    this.setData({
      DotStyle: e.detail.value
    })
  },
  // cardSwiper
  cardSwiper(e) {
    this.setData({
      cardCur: e.detail.current
    })
  },
  // towerSwiper
  // 初始化towerSwiper
  towerSwiper(name) {
    let list = this.data[name];
    for (let i = 0; i < list.length; i++) {
      list[i].zIndex = parseInt(list.length / 2) + 1 - Math.abs(i - parseInt(list.length / 2))
      list[i].mLeft = i - parseInt(list.length / 2)
    }
    this.setData({
      swiperList: list
    })
  },
  // towerSwiper触摸开始
  towerStart(e) {
    this.setData({
      towerStart: e.touches[0].pageX
    })
  },
  // towerSwiper计算方向
  towerMove(e) {
    this.setData({
      direction: e.touches[0].pageX - this.data.towerStart > 0 ? 'right' : 'left'
    })
  },
  // towerSwiper计算滚动
  towerEnd(e) {
    let direction = this.data.direction;
    let list = this.data.swiperList;
    if (direction == 'right') {
      let mLeft = list[0].mLeft;
      let zIndex = list[0].zIndex;
      for (let i = 1; i < list.length; i++) {
        list[i - 1].mLeft = list[i].mLeft
        list[i - 1].zIndex = list[i].zIndex
      }
      list[list.length - 1].mLeft = mLeft;
      list[list.length - 1].zIndex = zIndex;
      this.setData({
        swiperList: list
      })
    } else {
      let mLeft = list[list.length - 1].mLeft;
      let zIndex = list[list.length - 1].zIndex;
      for (let i = list.length - 1; i > 0; i--) {
        list[i].mLeft = list[i - 1].mLeft
        list[i].zIndex = list[i - 1].zIndex
      }
      list[0].mLeft = mLeft;
      list[0].zIndex = zIndex;
      this.setData({
        swiperList: list
      })
    }
  }
})