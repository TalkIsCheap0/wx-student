// pages/advice/advice.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    TabCur: '0',
    adviceList:[],
    oriAdviceList:[],
  },
  //切换顺序
  tabSelect(e) {
    if (this.data.TabCur == e.currentTarget.dataset.id){
    //console.log(this.data.adviceList.reverse());
    // let flag = 
    this.setData({
        TabCur: e.currentTarget.dataset.id == '0' ? '1' : '0',
      adviceList: this.data.oriAdviceList.filter(i => i.flag == e.currentTarget.dataset.id)
    });   
    }
  },
  //跳转详情页
  curAdvice(e){
    //console.log(e.currentTarget.dataset.id);
    let advice = JSON.stringify(this.data.adviceList[e.currentTarget.dataset.id])
    wx.navigateTo({
      url: '../curAdvice/curAdvice?advice=' + advice,
      success: function(res) {
      },
      fail: function(res) {},
      complete: function(res) {},
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    let that = this;
    wx.request({
      url: 'https://www.talkischeap0.cn/student/advice',
      data: {
        //测试数据
        sId: 123
      },
      success: function(res) {
        // console.log(res);
        that.setData({
          adviceList:res.data.adviceList.filter(i=>i.flag=='1'),
          oriAdviceList: res.data.adviceList
        })
      },
      fail: function(res) {},
      complete: function(res) {},
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})