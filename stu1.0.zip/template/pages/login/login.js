Page({

  /**
   * 页面的初始数据
   */
  data: {
    
  },
  formSubmit: function(e) {
    //console.log(e.detail.value);
    wx.request({
      url: 'https://www.talkischeap0.cn/student/login',
      data: {
        sId: e.detail.value.sId,
        pwd: e.detail.value.pwd
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success: function(res) {
        //console.log(res.data);
        if (res.statusCode == 200) {
          //访问正常
          if (res.data.code != 200) {
            wx.showToast({
              title: '密码错误，请重试！',
              icon: 'none',
              duration: 2000,
            })
          } else {
            //缓存
            wx.setStorage({
              key: "student",
              data: res.data
            });
            wx.showToast({
              title: "登陆成功",
              icon: 'success',
              duration: 500,
              success: function() {
                setTimeout(function() {
                  wx.switchTab({
                    url: '../mine/mine',
                  })
                }, 500)
              }
            })
          }
        }
      }
    })
  },
  sIdblur(e) {
    wx.request({
      url: 'https://www.talkischeap0.cn/student/login',
      data: {
        sId: e.detail.value
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success: function(res) {
        if (res.data.code == 201) {
          wx.showToast({
            title: '该用户不存在，请检查您的输入!',
            icon: 'none'
          })
        }
      }
    })
  }
})